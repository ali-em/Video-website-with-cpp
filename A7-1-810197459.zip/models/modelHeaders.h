#ifndef MODEL_HEADERS_H
#define MODEL_HEADERS_H

#include "comment.h"
#include "exceptions.h"
#include "film.h"
#include "notification.h"
#include "publisher.h"
#include "purchase.h"
#include "request_type.h"
#include "user.h"
#endif